<?PHP
header("location:admin_home.php");
?>