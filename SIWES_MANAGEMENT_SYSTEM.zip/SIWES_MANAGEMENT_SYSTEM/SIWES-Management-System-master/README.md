# SIWES Management System
An automated student internship monitoring system is long overdue. This system enables students update their learning progress as well as allow supervisors check in on them.

# How to Run

To run, you would need a web server stack package such as XAMPP, WAMPP or any of your choosing

1. Start the application. (Run Apache and MySQL on XAMPP)
2. Move/Copy siwes folder to the 'htdocs' folder on XAMPP or the 'www' folder on WAMPP
3. Navigate to PHPMyadmin in your browser and create a new database - sms
4. Import the sms.sql file.
5. In a new tab, run localhost/siwes

STUDENT LOGIN 
---------------------------
Student Login
Matric No.: 120591033
Password: 12345

STAFF LOGIN
---------------------------
Administrator 
Email: admin@admin.com
Password: 123456
---------------------------
Supervisor
Email: dosumuololade.u@gmail.com
Password: 12345

---------------------------

You're ready to go!
